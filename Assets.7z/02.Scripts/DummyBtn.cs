using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DummyBtn : MonoBehaviour
{
    public GameObject Dummybtn;
    
    void Start()
    {
        Dummybtn.SetActive(false);
    }

    void Update()
    {
        
    }

    public void DummyEvent()
    {
        Dummybtn.SetActive(true);
    }

    public void OnClickDummyBtn()
    {
        Dummybtn.SetActive(false);
    }
}
