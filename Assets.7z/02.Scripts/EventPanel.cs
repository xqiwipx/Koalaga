using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EventPanel : MonoBehaviour
{
    //기승전결 순서로 이미지삭제 뒤 다음 씬을 호출

    public GameObject EventImg0;
    public GameObject EventImg1;
    public GameObject EventImg2;
    public GameObject EventImg3;

    public int ImgNum = 4;
    void Start()
    {

    }

    void Update()
    {
        if (Input.GetMouseButtonUp(0))
        {
            ImgDestroy();
        }
    }

    public void ImgDestroy()
    {
        switch (ImgNum)
        {
            case 0:
                SceneManager.LoadScene(1);
                break;

            case 1:
                Destroy(EventImg3);
                break;

            case 2:
                Destroy(EventImg2);
                break;

            case 3:
                Destroy(EventImg1);
                break;

            case 4:
                Destroy(EventImg0);
                break;
        }
        ImgNum--;

    }

}
